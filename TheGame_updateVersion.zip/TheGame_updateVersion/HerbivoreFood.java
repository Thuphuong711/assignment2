package TheGame;

public interface HerbivoreFood {
    void reproduce(int x, int y, World world, int currentTurn);
}
