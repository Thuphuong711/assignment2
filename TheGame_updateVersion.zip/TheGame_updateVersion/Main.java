package TheGame;

public class Main {
    public static void main(String[] args) {
        //instantiate a new game
        Game game = new Game();

        /**
         * start the game and create the life and display life on the world
         * the world is the GUI board and the life is yellow and green cells( panels)
         */
        game.startGame();

        /**play the game -> this call gui.mouseClicked(new MouseEvent(gui, 0, 0, 0, 0, 0, 0, false));
         * this will call the mouseClicked method in the GUI class
         * then call the takeTurn method in the Game class
         * The takeTurn method will call the nextTurn method in the Game class
         * nextTurn method will call the action method in the LifeForm class and in this we update the currentTurn
         * currentTurn is the number of turns the game has taken so when we loop through the world and call the action method
         * we can check whether the Herbivore
         */
        game.play();
    }
}