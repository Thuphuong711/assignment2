package TheGame;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Plant extends LifeForm implements HerbivoreFood {
    public Plant() {
    }

    @Override
    public boolean isAnimal() {
        return false;
    }

    @Override
    public void action(int x, int y, World world, int currentTurn) {
        reproduce(x, y, world, currentTurn);
    }

    @Override
    public void reproduce(int x, int y, World world, int currentTurn) {
        if (super.getHasTakenAction() < currentTurn) {
            //get all the non animal cells around the current cell (x,y
            List<Cell> NonAnimalCells = world.getNonAnimalCells(x, y, world);
            List<Cell> EmptyCells = new ArrayList<>();
            int countEmpty = 0;
            int countPlant = 0;
            for (Cell cell : NonAnimalCells) {
                if (cell.getOccupant() == null) {
                    countEmpty++;
                    EmptyCells.add(cell);
                } else {
                    countPlant++;
                }
            }

            if (countEmpty >= 3 && countPlant == 4) {
                int rand = new Random().nextInt(EmptyCells.size());
                Cell newCell = EmptyCells.get(rand);
                // do I need to use LifeFormFactory class to create
                // a new instance of Plant here?
                newCell.setOccupant(new Plant());
//                System.out.println("new plant created at " + newCell.getRows() + " " + newCell.getCols());
            }
        }
        super.setHasTakenAction(currentTurn);
    }
}
