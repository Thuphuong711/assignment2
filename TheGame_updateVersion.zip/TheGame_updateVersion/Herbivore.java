package TheGame;

import java.util.List;
import java.util.Random;

public class Herbivore extends Animal {
    int turnNoFood = 0;

    public Herbivore() {
        super();
    }

    @Override
    public void action(int x, int y, World world, int currentTurn) {
        move(x, y, world, currentTurn);
    }

    @Override
    public void die(int x, int y, World world) {
        world.getCell(x, y).setOccupant(null);

    }

    @Override
    public void eat() {
        turnNoFood = 0;
    }

    public void move(int x, int y, World world, int currentTurn) {
        if (super.getHasTakenAction() < currentTurn) {
            List<Cell> NonAnimalCells = world.getNonAnimalCells(x, y, world);
            int rand = new Random().nextInt(NonAnimalCells.size());
            Cell newCell = NonAnimalCells.get(rand);

            if (newCell.getOccupant() instanceof Plant) {
//                System.out.println("Plant " + newCell.getRows() + " " + newCell.getCols() + " " + turnNoFood);
                eat();
            } else {
//                System.out.println("null " + newCell.getRows() + " " + newCell.getCols() + " " + turnNoFood);
                turnNoFood++;
                if (turnNoFood == 5) {
                    die(x, y, world);
                    //this return is really important
                    /**
                     * if we don't have this return, the program will continue to execute the next line
                     * which means newCell.setOccupant(this) will be executed -> this will make the herbivore move to the newCell/
                     * the newCell contains the herbivore. However, the herbivore is already dead. This is not what we want.
                     */
                    return;
                }
            }

            // when the return is executed -> these three lines are not executed
            newCell.setOccupant(this);
            world.getCell(x, y).setOccupant(null);
            super.setHasTakenAction(currentTurn);
        }

    }

}
