package TheGame;

public abstract class LifeForm {
    int hasTakenAction = 0;

    public LifeForm() {
    }

    public void action(int x, int y, World world, int currentTurn) {
    }

    public void reproduce(int x, int y, World world, int currentTurn) {
    }

    public void eat() {
    }

    public void move(int x, int y, World world, int currentTurn) {
    }

    public void die(int x, int y, World world) {
    }

    public void setHasTakenAction(int hasTakenAction) {
        this.hasTakenAction = hasTakenAction;
    }

    public int getHasTakenAction() {
        return hasTakenAction;
    }


    public abstract boolean isAnimal();
}
