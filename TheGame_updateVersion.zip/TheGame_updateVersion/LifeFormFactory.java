package TheGame;

public class LifeFormFactory {
    public static LifeForm createLifeForm(String type){
        if (type.equals("Animal")){
            return new Herbivore();
        } else return new Plant();
    }
}
