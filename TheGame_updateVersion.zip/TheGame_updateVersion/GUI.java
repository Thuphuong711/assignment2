package TheGame;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class GUI extends JFrame implements MouseListener {
    JFrame frame;
    Game game;
    JPanel panel = new JPanel();

    public GUI(Game game) {
        this.game = game;
        this.frame = new JFrame("Game of life ");
        this.frame.setSize(750, 750);
        this.frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.frame.setLayout(new GridLayout());
        this.frame.addMouseListener(this);
    }

    public void updateWorld(World world) {
        frame.getContentPane().removeAll();
        this.displayWorld(world);
        panel.revalidate();
        panel.repaint();
        frame.pack();
    }

    public void displayWorld(final World world) {
//        System.out.println("Displaying the world");

        int rows = world.rows;
        int cols = world.cols;

        Cell[][] layout = world.getLayout();

        this.frame.setLayout(new GridLayout(rows, cols));
        for (int i = 0; i < layout.length; i++) {
            for (int j = 0; j < layout[i].length; j++) {
                panel = new JPanel();
                int tileSize = 30;
                panel.setPreferredSize(new Dimension(tileSize, tileSize));
                LifeForm occupant = layout[i][j].getOccupant();
                if (occupant != null) {
                    if (occupant instanceof Herbivore) {
                        panel.setBackground(Color.YELLOW);
                    } else {
                        panel.setBackground(Color.GREEN);
                    }
                } else {
                    panel.setBackground(Color.WHITE);
                }
                panel.setBorder(BorderFactory.createLineBorder(Color.BLACK));
                panel.addMouseListener(this);
                frame.add(panel);
            }
        }

        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    /**
     * Invoked when the mouse button has been clicked (pressed
     * and released) on a component.
     *
     * @param e the event to be processed
     */
    @Override
    public void mouseClicked(MouseEvent e) {
        game.takeTurn();
    }

    // The following methods are not used
    @Override
    public void mousePressed(MouseEvent e) {
    }

    @Override
    public void mouseReleased(MouseEvent e) {
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }
}
