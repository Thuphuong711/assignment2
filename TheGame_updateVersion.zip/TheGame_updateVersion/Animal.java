package TheGame;

public class Animal extends LifeForm {
    public Animal() {
    }

    @Override
    public boolean isAnimal() {
        return true;
    }
}
