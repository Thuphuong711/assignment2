package TheGame;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public abstract class LifeForm {
    int hasTakenAction = 0;

    public LifeForm() {
    }

    public void action(int x, int y, World world, int currentTurn) {
    }

    public void action(int x, int y, World world, int currentTurn, int mates, int freeNeighbour, int foodNeighbour) {
    }

    public void reproduce(int x, int y, World world, int currentTurn, int mates, int freeNeighbour, int foodNeighbour) {
    }

    public void move(int x, int y, World world, int currentTurn) {
    }

    public void die(int x, int y, World world) {
        world.getCell(x, y).setOccupant(null);
    }


    public void setHasTakenAction(int hasTakenAction) {
        this.hasTakenAction = hasTakenAction;
    }

    public int getHasTakenAction() {
        return hasTakenAction;
    }


    public abstract boolean isAnimal();


    public void reproduce(int x, int y, World world, int currentTurn) {

    }

    public Cell choosePosition(int x, int y, World world){
        int rand = new Random().nextInt(world.getFreeNeighbour(x,y,world).size());
        Cell Cell = world.getFreeNeighbour(x,y,world).get(rand);
        return Cell;
    }

    public abstract boolean edible(LifeForm lifeForm);


//        if (this.getHasTakenAction() < currentTurn) {
//            //get all the non animal cells around the current cell (x,y
////            List<Cell> NonAnimalCells = world.getNonAnimalCells(x, y, world);
//            List<Cell> NeighbourCell = world.getNeighbourCells(x,y, world);
//            List<Cell> EmptyCells = new ArrayList<>();
//            int countEmpty = 0;
//            int countPlant = 0;
//            int countHerbivore = 0;
//            int countOmnivore = 0;
//            int countCarnivore = 0;
//
//            for (Cell cell : NeighbourCell) {
//                if (cell.getOccupant() == null) {
//                    countEmpty++;
//                    EmptyCells.add(cell);
//                } else if(cell.getOccupant() instanceof Plant) {
//                    countPlant++;
//                } else if(cell.getOccupant() instanceof Herbivore){
//                    countHerbivore++;
//                } else if(cell.getOccupant() instanceof Omnivore){
//                    countOmnivore++;
//                } else {
//                    countCarnivore++;
//                }
//            }
//
//            if (countEmpty >= freeNeighbour && countPlant >= 2) {
//                int rand = new Random().nextInt(EmptyCells.size());
//                Cell newCell = EmptyCells.get(rand);
//                // do I need to use LifeFormFactory class to create
//                // a new instance of Plant here?
//                newCell.setOccupant(LifeFormFactory.createLifeForm("Plant"));
////                System.out.println("new plant created at " + newCell.getRows() + " " + newCell.getCols());
//            }
//        }
//        this.setHasTakenAction(currentTurn);




}
