package TheGame;

public class Carnivore extends Animal implements OmnivoreEdible {
    public Carnivore(){
        super();
    }


    public boolean edible (LifeForm lifeForm){
        return lifeForm instanceof CarnivoreEdible;
    }

    public void eat(LifeForm lifeForm) {
        if(edible(lifeForm)) {
            turnNoFood = 0;
        }
    }

    public void reproduce(int x, int y, World world, int mates, int freeNeighbour, int foodNeighbour){
        if(mates>=1 && freeNeighbour>=3 && foodNeighbour == 2){
            Cell cell = super.choosePosition(x,y,world);
            cell.setOccupant(LifeFormFactory.createLifeForm("Carnivore"));
        }
    }
}
