package TheGame;

import java.util.List;
import java.util.Random;

public class Herbivore extends Animal implements CarnivoreEdible{

    public Herbivore() {
        super();
    }


    public void reproduce(int x, int y, World world, int currentTurn, int mates, int freeNeighbour, int foodNeighbour) {
        if(mates>=1 && freeNeighbour>=2 && foodNeighbour >= 2){
            Cell cell = super.choosePosition(x,y,world);
            cell.setOccupant(LifeFormFactory.createLifeForm("Herbivore"));
        }
    }

//    @Override
//    public void die(int x, int y, World world) {
//        world.getCell(x, y).setOccupant(null);
//
//    }


    public boolean edible (LifeForm lifeForm){
        return lifeForm instanceof HerbivoreEdible;
    }

    public void eat(LifeForm lifeForm) {
        if(edible(lifeForm)) {
            turnNoFood = 0;
        }
    }


//    public void move(int x, int y, World world, int currentTurn) {
//        if (super.getHasTakenAction() < currentTurn) {
//            List<Cell> NonAnimalCells = world.getNonAnimalCells(x, y, world);
//            int rand = new Random().nextInt(NonAnimalCells.size());
//            Cell newCell = NonAnimalCells.get(rand);
//
//            if (newCell.getOccupant() instanceof Plant) {
////                System.out.println("Plant " + newCell.getRows() + " " + newCell.getCols() + " " + turnNoFood);
//                eat();
//            } else {
////                System.out.println("null " + newCell.getRows() + " " + newCell.getCols() + " " + turnNoFood);
//                turnNoFood++;
//                if (turnNoFood == 5) {
//                    die(x, y, world);
//                    return;
//                }
//            }
//
//            // when the return is executed -> these three lines are not executed
//            newCell.setOccupant(this);
//            world.getCell(x, y).setOccupant(null);
//            super.setHasTakenAction(currentTurn);
//        }
//
//    }



}
