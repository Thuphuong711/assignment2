package TheGame;

public interface HerbivoreEdible {
}
