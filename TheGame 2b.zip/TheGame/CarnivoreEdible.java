package TheGame;

public interface CarnivoreEdible {
}
