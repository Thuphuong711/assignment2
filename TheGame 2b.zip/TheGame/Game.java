package TheGame;

import java.awt.event.MouseEvent;

public class Game {
    GUI gui;
    World world;
    int currentTurn;

    public Game() {
        world = new World(25, 25);
        gui = new GUI(this);
        currentTurn = 0;
    }

    public void startGame() {
        world.createLife();
        gui.displayWorld(world);
    }

    public void takeTurn() {
        this.nextTurn();
        gui.updateWorld(world);
    }

    private void nextTurn() {
        for (int i = 0; i < world.getRows(); i++) {
            for (int j = 0; j < world.getCols(); j++) {
                LifeForm occupant = world.getCell(i, j).getOccupant();
                if (occupant != null) {
                    int mate = world.getOccupant(i,j,world,occupant).size();
                    int freeNeighbour = world.getFreeNeighbour(i,j,world).size();
                    int foodNeighbour = world.getFoodNeighbour(i,j,world, occupant).size();
                    occupant.action(i, j, world, currentTurn, mate, freeNeighbour, foodNeighbour);
                }
            }
        }
        this.currentTurn++;
    }

    public void play() {
        gui.mouseClicked(new MouseEvent(gui, 0, 0, 0, 0, 0, 0, false));
    }

}