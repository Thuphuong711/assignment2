package TheGame;

import java.util.ArrayList;
import java.util.List;

public class World {
    int currentTurn;
    int rows;
    int cols;
    Cell[][] layout;

    public World(int rows, int cols) {
        this.currentTurn = 1;
        this.rows = rows;
        this.cols = cols;
        this.layout = new Cell[rows][cols];
    }

    public void createLife() {
        RandomGenerator.reset();
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                layout[i][j] = new Cell(i, j );
                int val = RandomGenerator.nextNumber(100);
                if (val >= 80) {
                    layout[i][j].setOccupant(LifeFormFactory.createLifeForm("Herbivore"));
                } else if (val >= 60) {
                    layout[i][j].setOccupant(LifeFormFactory.createLifeForm("Plant"));
                } else if(val >=50){
                    layout[i][j].setOccupant(LifeFormFactory.createLifeForm("Carnivore"));
                } else if(val >=45){
                    layout[i][j].setOccupant(LifeFormFactory.createLifeForm("Omnivore"));
                }
                else {
                    layout[i][j].setOccupant(null);
                }
            }
        }

    }




    public Cell[][] getLayout() {
        return layout;
    }

    public Cell getCell(int row, int col) {
        return layout[row][col];
    }

    public List<Cell> getNonAnimalCells(int x, int y, World world) {
        List<Cell> cells = new ArrayList<>();
        for (int i = x - 1; i <= x + 1; i++) {
            for (int j = y - 1; j <= y + 1; j++) {
                if (i >= 0 && i < world.rows && j >= 0 && j < world.cols && !(i == x && j == y)) {
                    LifeForm occupant = world.layout[i][j].getOccupant();
//                    if (world.layout[i][j].getOccupant() == null || !(world.layout[i][j].getOccupant() instanceof Herbivore)) {
                    if (occupant == null || !(occupant.isAnimal())) {
                        cells.add(world.layout[i][j]);
                    }
                }
            }
        }
        return cells;
    }

    public List<Cell> getNeighbourCells(int x, int y, World world) {
        List<Cell> cells = new ArrayList<>();
        for (int i = x - 1; i <= x + 1; i++) {
            for (int j = y - 1; j <= y + 1; j++) {
                if (i >= 0 && i < world.rows && j >= 0 && j < world.cols && !(i == x && j == y)) {
                    cells.add(world.layout[i][j]);
                }
            }
        }
        return cells;
    }

    public List<Cell> getOccupant(int x, int y, World world, LifeForm lifeForm){
        List<Cell> cells = new ArrayList<>();
        for (int i = x - 1; i <= x + 1; i++) {
            for (int j = y - 1; j <= y + 1; j++) {
                if (i >= 0 && i < world.rows && j >= 0 && j < world.cols && !(i == x && j == y)) {
                    LifeForm occupant = world.layout[i][j].getOccupant();
                    if(occupant != null && occupant.equals(lifeForm))
                        {
                            cells.add(world.layout[i][j]);
                        }
                }
            }
        }
        return cells;
    }

    public List<Cell> getFreeNeighbour(int x, int y, World world) {
        List<Cell> cells = new ArrayList<>();
        for (int i = x - 1; i <= x + 1; i++) {
            for (int j = y - 1; j <= y + 1; j++) {
                if (i >= 0 && i < world.rows && j >= 0 && j < world.cols && !(i == x && j == y)) {
                    LifeForm occupant = world.layout[i][j].getOccupant();
                    if (occupant == null) {
                        cells.add(world.layout[i][j]);
                    }
                }
            }
        }
        return cells;
    }

    public List<Cell> getFoodNeighbour(int x, int y, World world, LifeForm occupant ) {
        List<Cell> cells = new ArrayList<>();
        for (int i = x - 1; i <= x + 1; i++) {
            for (int j = y - 1; j <= y + 1; j++) {
                if (i >= 0 && i < world.getRows() && j >= 0 && j < world.getCols() && !(i == x && j == y)) {
                    LifeForm occupantNeighbour = world.layout[i][j].getOccupant();
                    if (occupant.edible(occupantNeighbour)) {
                        cells.add(world.layout[i][j]);
                    }
                }
            }
        }
        return cells;
    }

    public int getRows() {
        return rows;
    }

    public int getCols() {
        return cols;
    }

}
