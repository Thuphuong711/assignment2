package TheGame;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public abstract class LifeForm {
    int hasTakenAction = 0;

    public LifeForm() {
    }

    public void action(int x, int y, World world, int currentTurn, int mates, int freeNeighbour, int foodNeighbour) {
    }

    public void reproduce(int x, int y, World world, int currentTurn, int mates, int freeNeighbour, int foodNeighbour) {
    }


    public void die(int x, int y, World world) {
        world.getCell(x, y).setOccupant(null);
    }


    public void setHasTakenAction(int hasTakenAction) {
        this.hasTakenAction = hasTakenAction;
    }

    public int getHasTakenAction() {
        return hasTakenAction;
    }

    public Cell choosePositionToReproduce(int x, int y, World world){
        int rand = new Random().nextInt(world.getFreeNeighbour(x,y,world).size());
        return world.getFreeNeighbour(x,y,world).get(rand);
    }

    public abstract boolean isAnimal();
    public abstract boolean edible(LifeForm lifeForm);



}
