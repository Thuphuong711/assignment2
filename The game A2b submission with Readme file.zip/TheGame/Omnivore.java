package TheGame;

public class Omnivore extends Animal implements CarnivoreEdible{
    public Omnivore() {
        super();
    }


    public boolean edible (LifeForm lifeForm){
        return lifeForm instanceof OmnivoreEdible;
    }


    @Override
    public void reproduce(int x, int y, World world, int mates, int freeNeighbour, int foodNeighbour){
//        System.out.println("Enter reproduce method in Omnivore: mates: " + mates + " freeNeighbour "+ freeNeighbour + " foodNeighbour " + foodNeighbour);
        if(mates>=1 && freeNeighbour >= 3 && foodNeighbour == 1){
            Cell cell = super.choosePositionToReproduce(x,y,world);
            cell.setOccupant(LifeFormFactory.createLifeForm("Omnivore"));
//            System.out.println("reproducing omnivore");
        }
    }
}
