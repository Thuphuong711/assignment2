package TheGame;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Plant extends LifeForm implements HerbivoreEdible, OmnivoreEdible{
    public Plant() {
    }

    @Override
    public void action(int x, int y, World world, int currentTurn, int mates, int freeNeighbour, int foodNeighbour) {
        if (super.getHasTakenAction() < currentTurn){
            this.reproduce(x, y, world, currentTurn, mates, freeNeighbour, foodNeighbour);
        }
        super.setHasTakenAction(currentTurn);
    }

    @Override
    public boolean isAnimal() {
        return false;
    }

    @Override
    public boolean edible(LifeForm lifeForm) {
        return false;
    }


//    public void action(int x, int y, World world, int currentTurn, int mates, int freeNeighbour, int foodNeighbour) {
//        this.reproduce(x,y,world, currentTurn, mates, freeNeighbour, foodNeighbour);
//    }

//    public void reproduce(int x, int y, World world, int currentTurn, int mates, int freeNeighbour, int foodNeighbour){
//
//    }

//    public void reproduce(int x, int y, World world, int currentTurn) {
//        if (super.getHasTakenAction() < currentTurn) {
//            //get all the non animal cells around the current cell (x,y
//            List<Cell> NonAnimalCells = world.getNonAnimalCells(x, y, world);
//            List<Cell> EmptyCells = new ArrayList<>();
//            int countEmpty = 0;
//            int countPlant = 0;
//            for (Cell cell : NonAnimalCells) {
//                if (cell.getOccupant() == null) {
//                    countEmpty++;
//                    EmptyCells.add(cell);
//                } else {
//                    countPlant++;
//                }
//            }
//
//            if (countEmpty >= 3 && countPlant >= 2) {
//                int rand = new Random().nextInt(EmptyCells.size());
//                Cell newCell = EmptyCells.get(rand);
//                // do I need to use LifeFormFactory class to create
//                // a new instance of Plant here?
//                newCell.setOccupant(LifeFormFactory.createLifeForm("Plant"));
////                System.out.println("new plant created at " + newCell.getRows() + " " + newCell.getCols());
//            }
//        }
//        super.setHasTakenAction(currentTurn);
//    }


    public void reproduce(int x, int y, World world, int currentTurn, int mates, int freeNeighbour, int foodNeighbour){
//        System.out.println("Enter reproduce method in plant");
        if(mates >=2 && freeNeighbour >=3 && foodNeighbour == 0){
            Cell cell = super.choosePositionToReproduce(x,y,world);
            cell.setOccupant(LifeFormFactory.createLifeForm("Plant"));
//            System.out.println("reproducing plant");
        }
    }
}
