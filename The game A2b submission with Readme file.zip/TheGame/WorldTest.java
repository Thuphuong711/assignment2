package TheGame;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class WorldTest {

    @Test
    void testGetFoodNeighbour() {
        // Create a new World
        World world = new World(5, 5);

        // Populate the world with LifeForm objects
        // For simplicity, let's assume that LifeFormFactory.createLifeForm("Herbivore") returns a Herbivore object
        // and LifeFormFactory.createLifeForm("Plant") returns a Plant object
        world.getCell(2, 2).setOccupant(LifeFormFactory.createLifeForm("Herbivore"));
        world.getCell(1, 1).setOccupant(LifeFormFactory.createLifeForm("Plant"));
        world.getCell(1, 2).setOccupant(LifeFormFactory.createLifeForm("Plant"));
        world.getCell(1, 3).setOccupant(LifeFormFactory.createLifeForm("Plant"));
        world.getCell(2, 1).setOccupant(LifeFormFactory.createLifeForm("Plant"));
        world.getCell(2, 3).setOccupant(LifeFormFactory.createLifeForm("Plant"));
        world.getCell(3, 1).setOccupant(LifeFormFactory.createLifeForm("Plant"));
        world.getCell(3, 2).setOccupant(LifeFormFactory.createLifeForm("Plant"));
        world.getCell(3, 3).setOccupant(LifeFormFactory.createLifeForm("Plant"));

        // Call the getFoodNeighbour() method
        LifeForm herbivore = world.getCell(2, 2).getOccupant();
        List<Cell> foodNeighbours = world.getFoodNeighbour(2, 2, world, herbivore);

        // Check if the returned list of cells matches your expectations
        assertEquals(8, foodNeighbours.size(), "The number of food neighbours is incorrect");
        for (Cell cell : foodNeighbours) {
            assertTrue(cell.getOccupant() instanceof Plant, "The cell does not contain a Plant");
        }
    }
}