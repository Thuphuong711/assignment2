package TheGame;

import java.util.List;
import java.util.Random;

public class Herbivore extends Animal implements CarnivoreEdible{

    public Herbivore() {
        super();
    }

    @Override
    public void reproduce(int x, int y, World world, int mates, int freeNeighbour, int foodNeighbour) {
//        System.out.println("enter reproduce method in Herbivore: mates: " + mates + " freeNeighbour "+ freeNeighbour + " foodNeighbour " + foodNeighbour);
        if(mates>=1 && freeNeighbour>=2 && foodNeighbour >= 2){
            Cell cell = super.choosePositionToReproduce(x,y,world);
            cell.setOccupant(LifeFormFactory.createLifeForm("Herbivore"));
//            System.out.println("reproducing herbivore");
        }
    }

    public boolean edible (LifeForm lifeForm){
        return lifeForm instanceof HerbivoreEdible;
    }

}
