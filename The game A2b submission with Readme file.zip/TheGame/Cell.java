package TheGame;

public class Cell {
    LifeForm occupant;
    int rows;
    int cols;

    public Cell(int rows, int cols) {
        this.rows = rows;
        this.cols = cols;
    }

    public void setOccupant(LifeForm occupant) {
        this.occupant = occupant;
    }

    public LifeForm getOccupant() {
        return occupant;
    }
}
