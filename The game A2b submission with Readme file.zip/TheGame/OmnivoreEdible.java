package TheGame;

public interface OmnivoreEdible {
}
