package TheGame;

import java.util.List;
import java.util.Random;

public abstract class Animal extends LifeForm {
    int turnNoFood;

    public Animal() {
        turnNoFood = 0;
    }

    @Override
    public void action(int x, int y, World world, int currentTurn, int mates, int freeNeighbour, int foodNeighbour) {
        if (super.getHasTakenAction() < currentTurn) {
//        reproduce(x,y,world,currentTurn,mates,freeNeighbour,foodNeighbour);
            this.move(x, y, world, currentTurn);
            this.reproduce(x, y, world, mates, freeNeighbour, foodNeighbour);
//        System.out.println(freeNeighbour + " freeNeighbour");
//        System.out.println(mates + " mates");
//        System.out.println(foodNeighbour + " foodNeighbour");
        }
        super.setHasTakenAction(currentTurn);
    }


    public void eat(LifeForm lifeForm){
            turnNoFood =0;
    }


    public boolean isAnimal() {
        return true;
    }

    public abstract void reproduce(int x, int y, World world, int mates, int freeNeighbour, int foodNeighbour);


    public void move(int x, int y, World world, int currentTurn) {
        if (super.getHasTakenAction() < currentTurn) {
            List<Cell> neighbourCell = world.getNeighbourCells(x, y, world);
            int rand = new Random().nextInt(neighbourCell.size());
            Cell newCell = neighbourCell.get(rand);
            LifeForm occupant = newCell.getOccupant();

            if (this.edible(occupant)) {
//                System.out.println("Plant " + newCell.getRows() + " " + newCell.getCols() + " " + turnNoFood);
                    this.eat(occupant);
            } else {
//                System.out.println("null " + newCell.getRows() + " " + newCell.getCols() + " " + turnNoFood);
                turnNoFood++;
                if (turnNoFood == 5) {
                    super.die(x, y, world);
                    return;
                }
            }

            // when the return is executed -> these three lines are not executed
            newCell.setOccupant(this);
            world.getCell(x, y).setOccupant(null);
            super.setHasTakenAction(currentTurn);
        }

    }


}
