package TheGame;

public class LifeFormFactory {
    public static LifeForm createLifeForm(String type){
        return switch (type) {
            case "Herbivore" -> new Herbivore();
            case "Carnivore" -> new Carnivore();
            case "Omnivore" -> new Omnivore();
            case "Plant" -> new Plant();
            default -> null;
        };
    }
}
