package TheGame;

public class Cell {
    Life occupant;
    int rows;
    int cols;

    public Cell(int rows, int cols) {
        this.rows = rows;
        this.cols = cols;
    }

    public void setOccupant(Life occupant) {
        this.occupant = occupant;
    }

    public Life getOccupant() {
        return occupant;
    }
}
