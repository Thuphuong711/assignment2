package TheGame;

public abstract class Life {
    int hasTakenAction = 0;

    public Life() {
    }

    public void action(int x, int y, World world, int currentTurn) {
    }

    public void reproduce(int x, int y, World world, int currentTurn) {
    }

    public void eat() {
    }

    public void move(int x, int y, World world, int currentTurn) {
    }

    public void die(int x, int y, World world) {
    }

    public void setHasTakenAction(int hasTakenAction) {
        this.hasTakenAction = hasTakenAction;
    }

    public int getHasTakenAction() {
        return hasTakenAction;
    }

}
