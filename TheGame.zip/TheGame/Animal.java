package TheGame;

public class Animal extends Life {
    public Animal() {
    }
}
