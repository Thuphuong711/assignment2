package TheGame;

import java.util.List;
import java.util.Random;

public class Herbivore extends Animal {
    int turnNoFood = 0;

    public Herbivore() {
        super();
    }

    @Override
    public void action(int x, int y, World world, int currentTurn) {
        move(x, y, world, currentTurn);
    }

    @Override
    public void die(int x, int y, World world) {
        world.getCell(x, y).setOccupant(null);

    }

    @Override
    public void eat() {
        turnNoFood = 0;
    }

    public void move(int x, int y, World world, int currentTurn) {
        if (super.getHasTakenAction() < currentTurn) {
            List<Cell> NonAnimalCells = world.getNonAnimalCells(x, y, world);
            int rand = new Random().nextInt(NonAnimalCells.size());
            Cell newCell = NonAnimalCells.get(rand);

            if (newCell.getOccupant() instanceof Plant) {
//                System.out.println("Plant " + newCell.getRows() + " " + newCell.getCols() + " " + turnNoFood);
                eat();
            } else {
//                System.out.println("null " + newCell.getRows() + " " + newCell.getCols() + " " + turnNoFood);
                turnNoFood++;
                if (turnNoFood == 5) {
                    die(x, y, world);
                    return;
                }
            }

            newCell.setOccupant(this);
            world.getCell(x, y).setOccupant(null);
            super.setHasTakenAction(currentTurn);
        }

    }

}
