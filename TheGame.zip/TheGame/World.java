package TheGame;

import java.util.ArrayList;
import java.util.List;

public class World {
    int currentTurn;
    int rows;
    int cols;
    Cell[][] layout;

    public World(int rows, int cols) {
        this.currentTurn = 1;
        this.rows = rows;
        this.cols = cols;
        this.layout = new Cell[rows][cols];
    }

    public void createLife() {
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                layout[i][j] = new Cell(i, j );
                int random = RandomGenerator.nextNumber(100);
                if (random >= 85) {
                    layout[i][j].setOccupant(new Herbivore());
                } else if (random >= 65) {
                    layout[i][j].setOccupant(new Plant());
                } else {
                    layout[i][j].setOccupant(null);
                }
            }
        }

    }

    public Cell[][] getLayout() {
        return layout;
    }

    public Cell getCell(int row, int col) {
        return layout[row][col];
    }

    public List<Cell> getNonAnimalCells(int x, int y, World world) {
        List<Cell> cells = new ArrayList<Cell>();
        for (int i = x - 1; i <= x + 1; i++) {
            for (int j = y - 1; j <= y + 1; j++) {
                if (i >= 0 && i < world.rows && j >= 0 && j < world.cols && !(i == x && j == y)) {
                    if (world.layout[i][j].getOccupant() == null || !(world.layout[i][j].getOccupant() instanceof Herbivore)) {
                        cells.add(world.layout[i][j]);
                    }
                }
            }
        }
        return cells;
    }

    public int getRows() {
        return rows;
    }

    public int getCols() {
        return cols;
    }

}
